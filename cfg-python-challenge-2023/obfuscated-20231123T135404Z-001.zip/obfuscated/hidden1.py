F=float
A=print
import sys as B
C=B.argv[1:]
if len(C)<2:A('I require 2 numbers as input');B.exit()
elif len(C)>2:A('Stop being greedy!');B.exit()
try:D=F(C[0]);E=F(C[1])
except ValueError:A('Both numbers must be decimals');B.exit()
if D==0 and E==0:A('zero')
else:sum=abs(D)+abs(E);A(sum)